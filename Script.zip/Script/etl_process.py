import json
import pandas as pd
import mysql.connector
from mysql.connector import Error

# === MySQL Database Configuration ===
DB_CONFIG = {
    'host': 'localhost',
    'user': 'your_user',
    'password': 'your_password',
    'database': 'your_database'
}

# === File Paths ===
JSON_FILE_PATH = '/data/fake_property_data.json'
FIELD_CONFIG_PATH = 'data/Field Config.xlsx'

# === Load Field Config Mapping ===
def load_field_mapping():
    df = pd.read_excel(FIELD_CONFIG_PATH)
    df.columns = df.columns.str.strip()
    df['Column Name'] = df['Column Name'].str.strip()
    df['Target Table'] = df['Target Table'].str.strip()
    return df.groupby('Target Table')['Column Name'].apply(list).to_dict()

# === MySQL Connection ===
def get_connection():
    return mysql.connector.connect(**DB_CONFIG)

# === Insert Row Helper ===
def insert_row(cursor, table, data):
    columns = ', '.join(data.keys())
    placeholders = ', '.join(['%s'] * len(data))
    sql = f"INSERT INTO {table} ({columns}) VALUES ({placeholders})"
    cursor.execute(sql, list(data.values()))
    return cursor.lastrowid

# === Main ETL Function ===
def run_etl():
    # Load field mapping
    field_map = load_field_mapping()

    # Load JSON data
    with open(JSON_FILE_PATH, 'r') as f:
        records = json.load(f)

    # Connect to DB
    conn = get_connection()
    cursor = conn.cursor()

    for record in records:
        # Extract and insert property data
        property_data = {k: record.get(k) for k in field_map.get('property', []) if k in record}
        property_id = insert_row(cursor, 'property', property_data)

        # Insert into child tables
        for table in ['HOA', 'Rehab', 'Valuation', 'Taxes', 'Leads', 'leads']:
            if table in field_map:
                child_data = {k: record.get(k) for k in field_map[table] if k in record}
                child_data['property_id'] = property_id
                target_table = 'Leads' if table == 'leads' else table
                insert_row(cursor, target_table, child_data)

    # Commit and close
    conn.commit()
    cursor.close()
    conn.close()
    print("ETL process completed successfully.")

# === Run Script ===
if __name__ == '__main__':
    run_etl()
